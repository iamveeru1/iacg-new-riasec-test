
export enum ViewState {
  STUDENT_DETAILS = 'STUDENT_DETAILS',
  MILESTONES = 'MILESTONES',
  INSTRUCTIONS = 'INSTRUCTIONS',
  ASSESSMENT = 'ASSESSMENT',
  SUCCESS = 'SUCCESS',
  LOGIN = 'LOGIN',
  REGISTER = 'REGISTER',
}

export interface User {
  id?: string;
  docId?: string;
  name: string;
  school: string;
  studentClass?: string;
  email?: string;
  rollNumber?: string;
  rollNo?: string;
  parentName?: string;
  schoolAddress?: string;
  mobileNumber?: string;
  board?: string;
  schoolCode?: string;
  location?: string;
  counsellorEmail?: string;
  createdAt?: any;
  status?: string;
  tests?: { [testId: string]: any };
}

export interface Milestone {
  id: string;
  title: string;
  iconName: string; // mapping string to icon component
}

export interface Question {
  id: string;
  questionNumber?: string;
  subheading?: string;
  text: string;
  options?: string[];
  type: 'radio' | 'likert' | 'rating' | 'text' | 'checkbox' | 'textarea' | 'scale_0_4' | 'mcq';
  correctAnswer?: string;  // For MCQ: the correct option text
  explanation?: string;    // For MCQ: explanation shown after answering
}

export interface Section {
  id: string;
  title: string;
  questions: Question[];
}

export interface AssessmentData {
  milestoneId: string;
  sections: Section[];
}

export interface UserAnswers {
  [questionId: string]: string;
}